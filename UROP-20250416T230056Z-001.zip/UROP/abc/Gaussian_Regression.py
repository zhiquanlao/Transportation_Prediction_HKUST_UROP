# -*- coding: utf-8 -*-
"""
Created on Tue Oct 19 20:02:26 2021

@author: CHEN
"""
import pandas as pd
import numpy as np
dataMon=pd.read_pickle("C:/Users/CHEN/Desktop/Mon_in_out.pickle")
from sklearn.gaussian_process import GaussianProcessRegressor as GPR
from sklearn.gaussian_process.kernels import ConstantKernel, RBF
y=dataMon.groupby([dataMon.index.hour,dataMon.index.minute]).agg('median')
model=GPR(kernel=RBF(length_scale=2, length_scale_bounds=(2, 1e3)))
X=np.linspace(6,23,1021)
X=X.reshape(-1,1)
model.fit(X,y)
def predict(X):
    return model.predict(X)